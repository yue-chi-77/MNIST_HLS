// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMULTILAYERPERCEPTRON_H
#define XMULTILAYERPERCEPTRON_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmultilayerperceptron_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XMultilayerperceptron_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XMultilayerperceptron;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMultilayerperceptron_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMultilayerperceptron_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMultilayerperceptron_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMultilayerperceptron_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMultilayerperceptron_Initialize(XMultilayerperceptron *InstancePtr, UINTPTR BaseAddress);
XMultilayerperceptron_Config* XMultilayerperceptron_LookupConfig(UINTPTR BaseAddress);
#else
int XMultilayerperceptron_Initialize(XMultilayerperceptron *InstancePtr, u16 DeviceId);
XMultilayerperceptron_Config* XMultilayerperceptron_LookupConfig(u16 DeviceId);
#endif
int XMultilayerperceptron_CfgInitialize(XMultilayerperceptron *InstancePtr, XMultilayerperceptron_Config *ConfigPtr);
#else
int XMultilayerperceptron_Initialize(XMultilayerperceptron *InstancePtr, const char* InstanceName);
int XMultilayerperceptron_Release(XMultilayerperceptron *InstancePtr);
#endif

void XMultilayerperceptron_Start(XMultilayerperceptron *InstancePtr);
u32 XMultilayerperceptron_IsDone(XMultilayerperceptron *InstancePtr);
u32 XMultilayerperceptron_IsIdle(XMultilayerperceptron *InstancePtr);
u32 XMultilayerperceptron_IsReady(XMultilayerperceptron *InstancePtr);
void XMultilayerperceptron_EnableAutoRestart(XMultilayerperceptron *InstancePtr);
void XMultilayerperceptron_DisableAutoRestart(XMultilayerperceptron *InstancePtr);

void XMultilayerperceptron_Set_im(XMultilayerperceptron *InstancePtr, u64 Data);
u64 XMultilayerperceptron_Get_im(XMultilayerperceptron *InstancePtr);
void XMultilayerperceptron_Set_out_r(XMultilayerperceptron *InstancePtr, u64 Data);
u64 XMultilayerperceptron_Get_out_r(XMultilayerperceptron *InstancePtr);

void XMultilayerperceptron_InterruptGlobalEnable(XMultilayerperceptron *InstancePtr);
void XMultilayerperceptron_InterruptGlobalDisable(XMultilayerperceptron *InstancePtr);
void XMultilayerperceptron_InterruptEnable(XMultilayerperceptron *InstancePtr, u32 Mask);
void XMultilayerperceptron_InterruptDisable(XMultilayerperceptron *InstancePtr, u32 Mask);
void XMultilayerperceptron_InterruptClear(XMultilayerperceptron *InstancePtr, u32 Mask);
u32 XMultilayerperceptron_InterruptGetEnabled(XMultilayerperceptron *InstancePtr);
u32 XMultilayerperceptron_InterruptGetStatus(XMultilayerperceptron *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
