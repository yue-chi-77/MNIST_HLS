// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmultilayerperceptron.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMultilayerperceptron_CfgInitialize(XMultilayerperceptron *InstancePtr, XMultilayerperceptron_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMultilayerperceptron_Start(XMultilayerperceptron *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL) & 0x80;
    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMultilayerperceptron_IsDone(XMultilayerperceptron *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMultilayerperceptron_IsIdle(XMultilayerperceptron *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMultilayerperceptron_IsReady(XMultilayerperceptron *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMultilayerperceptron_EnableAutoRestart(XMultilayerperceptron *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XMultilayerperceptron_DisableAutoRestart(XMultilayerperceptron *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_AP_CTRL, 0);
}

void XMultilayerperceptron_Set_im(XMultilayerperceptron *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IM_DATA, (u32)(Data));
    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IM_DATA + 4, (u32)(Data >> 32));
}

u64 XMultilayerperceptron_Get_im(XMultilayerperceptron *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IM_DATA);
    Data += (u64)XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IM_DATA + 4) << 32;
    return Data;
}

void XMultilayerperceptron_Set_out_r(XMultilayerperceptron *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_OUT_R_DATA, (u32)(Data));
    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_OUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XMultilayerperceptron_Get_out_r(XMultilayerperceptron *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_OUT_R_DATA);
    Data += (u64)XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_OUT_R_DATA + 4) << 32;
    return Data;
}

void XMultilayerperceptron_InterruptGlobalEnable(XMultilayerperceptron *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_GIE, 1);
}

void XMultilayerperceptron_InterruptGlobalDisable(XMultilayerperceptron *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_GIE, 0);
}

void XMultilayerperceptron_InterruptEnable(XMultilayerperceptron *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IER);
    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IER, Register | Mask);
}

void XMultilayerperceptron_InterruptDisable(XMultilayerperceptron *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IER);
    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IER, Register & (~Mask));
}

void XMultilayerperceptron_InterruptClear(XMultilayerperceptron *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMultilayerperceptron_WriteReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_ISR, Mask);
}

u32 XMultilayerperceptron_InterruptGetEnabled(XMultilayerperceptron *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_IER);
}

u32 XMultilayerperceptron_InterruptGetStatus(XMultilayerperceptron *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMultilayerperceptron_ReadReg(InstancePtr->Control_BaseAddress, XMULTILAYERPERCEPTRON_CONTROL_ADDR_ISR);
}

