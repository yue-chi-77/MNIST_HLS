// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmultilayerperceptron.h"

extern XMultilayerperceptron_Config XMultilayerperceptron_ConfigTable[];

#ifdef SDT
XMultilayerperceptron_Config *XMultilayerperceptron_LookupConfig(UINTPTR BaseAddress) {
	XMultilayerperceptron_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMultilayerperceptron_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMultilayerperceptron_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XMultilayerperceptron_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMultilayerperceptron_Initialize(XMultilayerperceptron *InstancePtr, UINTPTR BaseAddress) {
	XMultilayerperceptron_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMultilayerperceptron_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMultilayerperceptron_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMultilayerperceptron_Config *XMultilayerperceptron_LookupConfig(u16 DeviceId) {
	XMultilayerperceptron_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMULTILAYERPERCEPTRON_NUM_INSTANCES; Index++) {
		if (XMultilayerperceptron_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMultilayerperceptron_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMultilayerperceptron_Initialize(XMultilayerperceptron *InstancePtr, u16 DeviceId) {
	XMultilayerperceptron_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMultilayerperceptron_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMultilayerperceptron_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

